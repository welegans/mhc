<nav class="navbar navbar-toggleable-md fixed-top navbar-light" style="background:#fff;">
  <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <a class="navbar-brand" href="<?php echo e(route('home')); ?>"><img src="<?php echo e(asset('imgs/l4.png')); ?>" width="200" height="50" alt="">
    
  </a>
  <div class="collapse navbar-collapse" id="navbarNav">
    <ul class="navbar-nav">
      <li class="nav-item ">
        <a class="nav-link" href="<?php echo e(route('home')); ?>">Home</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="<?php echo e(route('about')); ?>">About</a>
      </li>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Hajj
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
          <a class="dropdown-item" href="<?php echo e(route('haj')); ?>">About Hajj</a>
          <!-- <a class="dropdown-item" href="<?php echo e(route('hajpackage')); ?>">Hajj packages</a> -->
          
        </div>
      </li>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Umrah
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
          <a class="dropdown-item" href="<?php echo e(route('umrah')); ?>">About Umrah</a>
          <!-- <a class="dropdown-item" href="<?php echo e(route('umrahpackage')); ?>">Umrah packages</a> -->
          
        </div>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#">Gallery</a>
      </li>
      <li class="nav-item">
        <a class="nav-link " href="<?php echo e(route('contact')); ?>">Contact</a>
      </li>
    </ul>
  </div>
</nav>
