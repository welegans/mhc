<!DOCTYPE html>
<html>
  <head>
    <?php echo $__env->make('layout.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  </head>
  <body>
      <?php echo $__env->make('layout.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php $__env->startSection('main-content'); ?>

    <?php echo $__env->yieldSection(); ?>

  <?php echo $__env->make('layout.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  </body>
</html>
