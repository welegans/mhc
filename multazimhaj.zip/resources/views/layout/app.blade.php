<!DOCTYPE html>
<html>
  <head>
    @include('layout.head')
  </head>
  <body>
      @include('layout.header')
    @section('main-content')

    @show

  @include('layout.footer')
  </body>
</html>
